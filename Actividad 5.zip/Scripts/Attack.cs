using UnityEngine;

public class Attack : MonoBehaviour
{
    public float attackRange = 2f;        // Alcance del golpe cuerpo a cuerpo
    public int damage = 1;               // Daño que inflige el golpe
    public LayerMask enemyLayer;          // Capa del enemigo para que solo afecte a enemigos
    public Transform attackPoint;         // Punto de referencia desde donde sale el golpe (normalmente la posición del arma o la cámara del jugador)

    void Update()
    {
        // Detectar cuando el jugador pulsa la tecla para golpear
        if (Input.GetButtonDown("Fire1"))
        {
            PerformMeleeAttack();
        }
    }

    void PerformMeleeAttack()
    {
        // Crear un área de colisión esférica para detectar enemigos en el rango de ataque
        Collider[] hitEnemies = Physics.OverlapSphere(attackPoint.position, attackRange, enemyLayer);

        // Aplicar daño a cada enemigo dentro del rango
        foreach (Collider enemy in hitEnemies)
        {
            // Asumimos que los enemigos tienen un script con el método TakeDamage
            enemy.GetComponent<EnemyHealth>().TakeDamage(damage);
        }
    }

    // Este método es opcional para visualizar el rango de ataque en la vista de escena de Unity
    void OnDrawGizmosSelected()
    {
        if (attackPoint == null)
            return;

        // Dibujar una esfera en el editor para mostrar el alcance del ataque
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(attackPoint.position, attackRange);
    }
}
