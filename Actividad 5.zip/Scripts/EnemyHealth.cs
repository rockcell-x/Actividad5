using UnityEngine;

public class EnemyHealth : MonoBehaviour
{
    public int lives = 3;  // Cantidad de vidas iniciales
    private Renderer objectRenderer;  // Referencia al componente Renderer para cambiar el color

    void Start()
    {
        // Obtener el componente Renderer del objeto
        objectRenderer = GetComponent<Renderer>();

        // Configurar el color inicial basado en las vidas
        UpdateColor();
    }

    // Método para reducir vidas
    public void TakeDamage(int damage)
    {
        // Reducir las vidas según el daño recibido
        lives -= damage;

        // Actualizar el color según las vidas restantes
        UpdateColor();

        // Si las vidas llegan a 0, destruir el objeto
        if (lives <= 0)
        {
            Destroy(gameObject);
        }
    }

    // Método para cambiar el color basado en las vidas
    void UpdateColor()
    {
        if (lives == 3)
        {
            objectRenderer.material.color = Color.green;  // Verde cuando tiene 3 vidas
        }
        else if (lives == 2)
        {
            objectRenderer.material.color = Color.yellow;  // Amarillo cuando tiene 2 vidas
        }
        else if (lives == 1)
        {
            objectRenderer.material.color = Color.red;  // Rojo cuando tiene 1 vida
        }
    }
}